from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Student
from .forms import StudentForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

@login_required(login_url='login')
def home(request):
    students = Student.objects.all()
    return render(request, 'students/home.html', {'students': students})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, "students/login.html", {"error": "Invalid username or password"})
    return render(request, "students/login.html")


def logout_view(request):
    logout(request)
    return redirect('login')


def home(request):
    students = Student.objects.all()
    return render(request, 'students/home.html', {'students': students})


def add_student(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Student added successfully!")
            return redirect('home')
    else:
        form = StudentForm()
    return render(request, 'students/add_student.html', {'form': form})


def edit_student(request,student_id):
    student = get_object_or_404(Student, id=student_id)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student details updated successfully!")
            return redirect('home')
    else:
        form = StudentForm(instance=student)
    return render(request, 'students/edit_student.html', {'form': form})


def delete_student(request, id):
    student = get_object_or_404(Student, id=id)
    student.delete()
    messages.warning(request, "Student deleted successfully!")
    return redirect('home')
